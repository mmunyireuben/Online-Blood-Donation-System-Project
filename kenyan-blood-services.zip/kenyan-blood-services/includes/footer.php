

  <footer class="py-5 bg-inverse">
        <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; <?php echo date('Y'); ?> Kenyan Blood Services</p>
        </div>
        <!-- /.container -->
    </footer>
